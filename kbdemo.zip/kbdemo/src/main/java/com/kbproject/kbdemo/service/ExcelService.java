package com.kbproject.kbdemo.service;

    import com.kbproject.kbdemo.model.Employee;
    import org.apache.poi.ss.usermodel.*;
    import org.springframework.stereotype.Service;

    import java.io.ByteArrayOutputStream;
    import java.io.IOException;
    import java.util.List;

//public class ExcelService {
//}
;

@Service
public class ExcelService {

    public byte[] exportToExcel(List<Employee> employees) throws IOException {
        try (Workbook workbook = WorkbookFactory.create(true);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Employees");
            createHeaderRow(sheet);
            createDataRows(sheet, employees);

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private void createHeaderRow(Sheet sheet) {
        Row headerRow = sheet.createRow(0);
        String[] headers = {"ID", "First Name", "Last Name", "Contact Number", "Email ID", "Employee ID"};

        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }
    }

    private void createDataRows(Sheet sheet, List<Employee> employees) {
        int rowNum = 1;
        for (Employee employee : employees) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(employee.getId());
            row.createCell(1).setCellValue(employee.getFirstName());
            row.createCell(2).setCellValue(employee.getLastName());
            row.createCell(3).setCellValue(employee.getContactNumber());
            row.createCell(4).setCellValue(employee.getEmailId());
            row.createCell(5).setCellValue(employee.getEmployeeId());
        }
    }
}
