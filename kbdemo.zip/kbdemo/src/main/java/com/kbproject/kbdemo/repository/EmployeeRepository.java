package com.kbproject.kbdemo.repository;

//public class EmployeeRepository {
//}
//package com.example.employeeapi.repository;

        import com.kbproject.kbdemo.model.Employee;
        import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Employee findByEmployeeId(String employeeId);
    Employee findByEmailId(String emailId);
}
