package com.kbproject.kbdemo.controller;

//public class EmployeeController {
//}
import com.kbproject.kbdemo.model.Employee;
import com.kbproject.kbdemo.repository.EmployeeRepository;
import com.kbproject.kbdemo.service.ExcelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ExcelService excelService;

    @PostMapping
    public ResponseEntity<?> addEmployee(@RequestBody @Valid Employee employee) {
        try {
            return ResponseEntity.ok(employeeRepository.save(employee));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> getAllEmployees() {
        try {
            List<Employee> employees = employeeRepository.findAll();
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/{idOrEmail}")
    public ResponseEntity<?> getEmployeeByIdOrEmail(@PathVariable String idOrEmail) {
        try {
            Employee employee;
            if (idOrEmail.contains("@")) {
                employee = employeeRepository.findByEmailId(idOrEmail);
            } else {
                employee = employeeRepository.findByEmployeeId(idOrEmail);
            }

            if (employee != null) {
                return ResponseEntity.ok(employee);
            } else {
                return ResponseEntity.badRequest().body("Employee not found");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editEmployee(@PathVariable Long id, @RequestBody @Valid Employee updatedEmployee) {
        try {
            Employee employee = employeeRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Employee not found with id: " + id));

            employee.setFirstName(updatedEmployee.getFirstName());
            employee.setLastName(updatedEmployee.getLastName());
            employee.setContactNumber(updatedEmployee.getContactNumber());
            employee.setEmailId(updatedEmployee.getEmailId());

            return ResponseEntity.ok(employeeRepository.save(employee));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable Long id) {
        try {
            employeeRepository.deleteById(id);
            return ResponseEntity.ok("Employee deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/exportToExcel")
    public ResponseEntity<?> exportToExcel() {
        try {
            List<Employee> employees = employeeRepository.findAll();
            byte[] excelBytes = excelService.exportToExcel(employees);
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=employees.xlsx")
                    .body(excelBytes);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
}
